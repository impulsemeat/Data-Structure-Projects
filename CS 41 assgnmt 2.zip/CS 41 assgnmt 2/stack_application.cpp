// FILE: stack_application.cpp
// This the the main program to test drive the stack member
// function you have developed in stack2.cpp.

// It evalutes each given postfix expression using stacks
// and print out the result value.
// If the given expression is an invlid one, then the program
// prints approopriate error emssaages.

#include <cassert>  // Provides assert
#include "node1.h"  // Node class and Linked_list Toolkit
#include "stack2.h"

#include <cctype>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

using namespace ivc_cs41_pa2;

double read_and_evaluate(istream& ins);

int main()
{
    //Codes that create stack, input postfix expression,
    // evaluate it, and print the resulting value or error messages.

    //This part is to be completed by students
    ifstream inClientFile("input.txt", ios::in);
    if (!inClientFile)
    {
		cerr << "File could not be opened" << endl;
		exit(EXIT_FAILURE);
	}
	cout << "A postfix expression is imported from input.txt\n";
	double answer;
	answer = read_and_evaluate(inClientFile);
	inClientFile.close();
	cout << "That evaluates to " << answer << endl << endl;

    ofstream outClientFile("output.txt", ios::out);
    if (!outClientFile)
    { // overloaded ! operator
		cerr << "File could not be opened" << endl;
		exit(EXIT_FAILURE);
	}
	outClientFile << "That evaluates to " << answer << endl;
	cout << "The result is exported to output.txt\n";

	return EXIT_SUCCESS;

}

double read_and_evaluate(istream& ins)
{
    assert(ins);
    stack2 *numbers = new stack2;
    //numbers->empty();// For debugging

    double number;
    char symbol;

    while(!ins.eof() && ins.peek()!= '\n')
    {
        if(isdigit(ins.peek()) || (ins.peek() == '.'))
        {
            ins >> number;
            numbers->push(number);
            //numbers->empty();//For debugging
        }
        else if(strchr("+-*/^", ins.peek()) != NULL)
        {
            ins >> symbol;
            //cout << symbol << endl; // For debugging
            double operand2 = numbers->top();
            numbers->pop();
            //numbers.empty();
            double operand1 = numbers->top();
            numbers->pop();
            //numbers.empty();
            switch(symbol)
            {
                case '+':
                    {
                        numbers->push(operand1 + operand2);
                        break;
                    }
                case '-':
                    {
                        numbers->push(operand1 - operand2);
                        break;
                    }
                case '*':
                    {
                        numbers->push(operand1 * operand2);
                        break;
                    }
                case '/':
                    {
                        numbers->push(operand1 / operand2);
                        break;
                    }
                case '^':
                    {
                        numbers->push(pow(operand1, operand2));
                        break;
                    }
            }
            //numbers->empty(); //For debugging
        }
        else
            ins.ignore();
    }
    double result = numbers->top();
    //cout << endl << result << "!" << endl; //For debugging
    delete numbers;
    //cout << endl << result << "!!" << endl; //For debugging
    return result;
}
