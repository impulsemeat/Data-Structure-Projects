// FILE: stack2.cpp
// CLASS IMPLEMENTED: stack (see stack2.h for documentation)
// INVARIANT for the stack class:
//   1. The items in the stack are stored in a linked list, with the top of the
//      stack stored at the head node, down to the bottom of the stack at the
//      final node.
//   2. The member variable top_ptr is the head pointer of the linked list.

#include <cassert>  // Provides assert
#include "node1.h"  // Node class and Linked_list Toolkit
#include "stack2.h"
#include <iostream>
#include <cstdlib>

namespace ivc_cs41_pa2
{
//Codes that implement the functions specified in stack class definition

//This part is to be completed by stidents
     stack2::stack2()
    {
        top_ptr = NULL;
    }

    stack2::stack2(const stack2& source)
    {
        node* temp_tail_ptr = NULL;
        list_copy(source.top_ptr, this->top_ptr, temp_tail_ptr);
    }

    stack2::~stack2()
    {
        while (top_ptr != NULL)
        {
            pop();
        }
    }

    void stack2::push(node::value_type entry)
    {
        list_head_insert(top_ptr, entry);
    }

    void stack2::pop()
    {
        list_head_remove(this->top_ptr);
    }

    node::value_type stack2::top()
    {
        return top_ptr->data();
    }

    //stack stack::operator=functionsnode()??
    stack2::size_type stack2::size()
    {
        return list_length(this->top_ptr);
    }

    void stack2::empty()
    {
        if (this->top_ptr == NULL)
            std::cout << "This stack is empty.\n";
        else
            std::cout << "This stack is not empty.\n" << top() << std::endl;
    }

    stack2& stack2::operator= (const stack2& source_stack)
    {
        node* temp_tail_ptr = NULL;
        list_copy(source_stack.top_ptr, this->top_ptr, temp_tail_ptr);// here, what does functionsnode() mean? as well as in prototype.
        return *this;
    }

}
