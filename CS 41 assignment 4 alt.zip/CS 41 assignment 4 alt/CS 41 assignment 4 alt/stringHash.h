#pragma once
#include <cstdlib> // Provides size_t
#include <string>
#include <vector>

using namespace std;

typedef int(*hkey)(const string&);

template<size_t TABLE_SIZE, hkey hash>
class stringHash
{
public:
	stringHash();
	~stringHash();
	void insert(const string&);
	void remove(const string&);
	bool find(const string&);
	int size() const { return totalNum; }
	int collisions() const { return collision;  }
	void printFromTo(int, int) const;
	//int const table_size = (int)TABLE_SIZE;
private:
	vector<string> *data[TABLE_SIZE];
	hkey hash;
	int collision, totalNum;
};

#include "stringHash.template"
