//FILE: CS 41 aasignment 4
//Including main()
#include <iostream>
#include <fstream>
#include "stringHash.h"
#include <string>
#include <vector>
#include <cstdlib>
using namespace std;

template<size_t TABLE_SIZE>
int hashkey(const string& s)
{
	int value = 0;
	for (size_t i = 0; i < s.length(); i++)
		value += static_cast<int>(s.[i]);
	return (value % stringHash<string, TABLE_SIZE, hashkey>.size);
}

int main()
{
	ifstream inFile("wordlistab.txt", ios::in);
	if (!inFile) {
		cerr << "File could not be opened" << endl;
		exit(EXIT_FAILURE);
	}
	size_t const dic_size = 653;
	stringHash<dic_size, hashkey<dic_size>> dictionary;
	int i = 0; //count the words added from the file
	while (inFile.peek() != EOF)
	{
		string entry;
		inFile >> entry;
		dictionary.insert(entry);
		i++;
	}
	cout << "File import completed\n";
	cout << "The collision found now is " << dictionary.collisions() << endl;
	cout << "The total number of words added from file is " << i << endl;
	cout << "The first twenty words are as follow\n";
	dictionary.printFromTo(1, 20);//Print contents from the first to the twentieth
	cout << "The total number of words in the dictionary is " << dictionary.size() << endl;
	inFile.close();
	char choice;
	do 
	{
		cout << "Please seclect follow options to operate the dictionary\n"
			<< "A for adding a word to the dictionary\n"
			<< "D for deleting a word from the dictionary\n"
			<< "S for searching a word in the dicitonay\n"
			<< "T for the total number of words in the dicitonary\n"
			<< "P for printing out a certern of words in the dicitonary\n"
			<< "C for how many collisions in the dicitonary implementation\n"
			<< "Q for exit\n";
		cin >> choice;
		choice = toupper(choice);
		switch (choice)
		{
		case 'A':
		{
			cout << "please enter a word you would like to add without white space:\n";
			string entry;
			cin >> entry;
			dictionary.insert(entry);
			break;
		}
		case 'D':
		{
			cout << "please enter a word you would like to remove without white space:\n";
			string entry;
			cin >> entry;
			dictionary.remove(entry);
			break;
		}
		case 'S':
		{
			cout << "please enter a word you would like to search without white space:\n";
			string entry;
			cin >> entry;
			if (dictionary.find(entry))
				cout << "The word," << entry << ", exists in the dicitonary\n";
			else
				cout << "The word," << entry << ", does not exist in the dicitonary\n";
			break;
		}
		case 'T':
		{
			cout << "The total number of words in the dicitonary is " << dictionary.size() << endl;
			break;
		}
		case 'P':
		{
			int From, To;
			cout << "Enter an interger number to indicate which of the word in order you would print from: ";
			cin >> From;
			cout << "Enter an interger number to indicate which of the word in order you would print to: ";
			cin >> To;
			dictionary.printFromTo(From, To);
		}
		case 'C':
		{
			cout << "The collision found now is " << dictionary.collisions() << endl;
			break;
		}
		case 'Q':
		{
			cout << "Exiting\n";
			break;
		}
		default:
			cout << "Wrong Option";
			break;
		}
	} while (choice != 'Q');
	return EXIT_SUCCESS;
}