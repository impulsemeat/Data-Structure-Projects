// FILE: bt_class.template
// IMPLEMENTS: The binary_tree class (see bt_class.h for documentation).
#include <cassert>    // Provides assert
#include <cstdlib>   // Provides NULL, std::size_t
#include <iomanip>    // Provides std::setw
#include <iostream>   // Provides std::cout
#include "bt.h"
namespace main_savitch_10
{
	// You provide the implementation code of template functions specified in
	// the bt_class.h file
	template <class Item>
	binary_tree<Item>::binary_tree()
	{
		root = NULL;
		current = root;
	}

	template <class Item>
	binary_tree<Item>::binary_tree(const binary_tree<Item>& source)
	{
		this->root = tree_copy(source.root);
		this->current = root;//tree_search(this->root, source.retrieve());
	}

	template <class Item>
	binary_tree<Item>::~binary_tree()
	{
		tree_clear(this->root);
		delete this->current;
	}

	template <class Item>
	void binary_tree<Item>::create_first_node(const Item& entry)
	{
		assert(tree_size(this->root) == 0);
		this->root = new binary_tree_node<Item>(entry);
	}

	template <class Item>
	void binary_tree<Item>::change(const Item& new_entry)
	{
		assert((tree_size(this->root) > 0) && (this->current != NULL));
			this->current->set_data(new_entry);
	}

	template <class Item>
	void binary_tree<Item>::add_left(const Item& entry)
	{
		assert((tree_size(this->root) > 0) && (this->current != NULL));
			if (current->left() != NULL)
			{
				std::cerr << "The current node has already had a left child" << std::endl;
				return;
			}
		//binary_tree_node<Item> *temp = new binary_tree_node<Item>(entry);
		current->set_left(new binary_tree_node<Item>(entry));
		//delete temp;
	}

	template <class Item>
	void binary_tree<Item>::add_right(const Item& entry)
	{
		assert((tree_size(this->root) > 0) && (this->current != NULL));
			if (current->right() != NULL)
			{
				std::cerr << "The current node has already had a right child" << std::endl;
				return;
			}
		//binary_tree_node<Item> *temp = new binary_tree_node<Item>(entry);
		current->set_right(new binary_tree_node<Item>(entry));
		//delete temp;
	}

	template <class Item>
	std::size_t binary_tree<Item>::size() const
	{
		return tree_size(this->root);
	}

	template <class Item>
	Item binary_tree<Item>::retrieve() const
	{
		return this->current->data();
	}

	template <class Item>
	bool binary_tree<Item>::has_parent() const
	{
		if (tree_size(root) == 0)
			return false;
		else
			return !(current == root);
	}

	template <class Item>
	bool binary_tree<Item>::has_left_child() const
	{
		if (tree_size(root) == 0)
			return false;
		else
			return !(current->left() == NULL);
	}

	template <class Item>
	bool binary_tree<Item>::has_right_child() const
	{
		if (tree_size(root) == 0)
			return false;
		else
			return !(current->right() == NULL);
	}


}
