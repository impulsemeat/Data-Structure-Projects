//File: main.cpp
//For CS 41 assignment 3
#include <iostream>
#include <cassert>
#include <cstdlib>
#include <cctype>
#include <fstream>
#include "bt.h"
#include "binarytree.h"
#include <string>
using namespace std;
using namespace main_savitch_10;

char get_user_integer();

int main()
{
	char choice;
	binary_tree<int> testTree;
	binary_tree<int> *test;
	test = &testTree;

	int i;
	char* inname = "text.txt";


	/*ofstream writefile;
	writefile.open("text.txt", ios_base::out);
	writefile << 2 << endl;
	writefile << 4;
	writefile.close();*/

	ifstream infile ( inname, ios::in );
	cout << "Opened " << inname << " for reading." << endl;
	while (infile >> i)
	{
		cout << "Value from file is " << i << endl;
		if (test->size() == 0)
		{
			test->create_first_node(i);
		}
		else if (test->retrieve() == i) { continue; }
		else if (test->retrieve() != i)
		{
			test->add_bsNode(i);
		}
		cout << "and " << i << " is inserted in tree" << endl;
	}
	infile.close();
		cout << "okay! now binary tree is completed" << endl;
		cout << "what do you want to do from now on? select among A,D,S,F,Q" << endl;

	do {
		cout << "Choose A to add integer" << endl;
		cout << "Choose D to delete integer" << endl;
		cout << "Choose S to show all integer in tree" << endl;
		cout << "Choose F to find certain integer in tree" << endl;
		cout << "Choose Q to exit this menu" << endl;
		choice = toupper(get_user_integer());
		switch (choice)
		{
		case 'A':
		{
			int addone;
			cout << "Type in your integer: ";
			cin >> addone;
			test->add_bsNode(addone);
			break;
		}
		case 'D':
		{
			int search_one;
			cout << "Type in your integer: ";
			cin >> search_one;
			binary_tree_node<int>* temp = test->search_bsNode(search_one);
			if (temp == NULL)
			{
				cout << "Your input is not found\n";
			}
			else
			{
				cout << search_one << "is found to be deleted.\n";
				delete temp;
			}
			break;
		}
		case 'S':
		{
			print(test->getRoot(), 1);
			break;
		}
		case 'F':
		{
			int search_one;
			cout << "Type in your integer: ";
			cin >> search_one;
			if ( test->search_bsNode(search_one) == NULL)
			{
				cout << "Your input is not found\n";
			}
			else
			{
				cout << search_one << "is found to be deleted.\n";
				print(test->search_bsNode(search_one), 1);
			}
			break;
		}
		default:
		{
			cout << "Wrong Choice. Choose again.\n";
		}
		}

	} while (choice != 'Q');
	return EXIT_SUCCESS;
}

char get_user_integer()
	{
		char a;
		cin >> a;
		return a;
	}



