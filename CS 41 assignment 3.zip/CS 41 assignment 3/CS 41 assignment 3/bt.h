//File: bt.h
#ifndef BT_CLASS_H
#define BT_CLASS_H
#include <cstdlib>    // Provides size_t
#include "binarytree.h"  // Provides binary_tree_node<Item> template class

namespace main_savitch_10
{
	template <class Item>
	class binary_tree
	{
	public:
		// CONSTRUCTORS and DESTRUCTOR
		binary_tree();
		binary_tree(const binary_tree& source);
		~binary_tree();
		// MODIFICATION MEMBER FUNCTIONS
		void add_bsNode(const Item&);
		void create_first_node(const Item& entry);
		void change(const Item& new_entry);
		void add_left(const Item& entry);
		void add_right(const Item& entry);
		// CONSTANT MEMBER FUNCTIONS
		binary_tree_node<Item>* search_bsNode(const Item&) const;
		binary_tree_node<Item>* search_bsNodeCurrent(const Item&) const;
		std::size_t size() const;
		Item retrieve() const;
		binary_tree_node<Item>* getRoot() const { return root; }
		binary_tree_node<Item>* getCurrent() const { return current; }
		bool has_parent() const;
		bool has_left_child() const;
		bool has_right_child() const;
	private:
		// Private member variables to be specified by the student.
		// My own implementation has a root pointer and a pointer to
		// the "current" node, plus a member variable to keep track of
		// the number of nodes in this tree.
		binary_tree_node<Item> *root;
		binary_tree_node<Item> *current;

	};

	

}

#include "bt.template"
#endif 
