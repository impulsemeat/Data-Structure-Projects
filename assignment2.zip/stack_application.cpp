// FILE: stack_application.cpp
// This the the main program to test drive the stack member 
// function you have developed in stack2.cpp.

// It evalutes each given postfix expression using stacks 
// and print out the result value.
// If the given expression is an invlid one, then the program 
// prints approopriate error emssaages.

#include <cassert>  // Provides assert
#include "node1.h"  // Node class and Linked_list Toolkit
#include "stack2.h"

namespace ivc_cs41_pa2
{
//Codes that create stack, input postfix expression, 
// evaluate it, and print the resulting value or error messages.

//This part is to be completed by stidents
    . . .
}
