// FILE: stack2.h 
// CLASS PROVIDED: stack (part of the namespace ivc_cs41_pa2)
//
// TYPEDEFS for the stack class:
//   stack::value_type is the data type of the items in the stack,
//   It may be any of the C++ built-in types (int, char, etc.), or a class
//   with a default constructor, a copy constructor, and an assignment
//   operator. 
//   stack::size_type is the data type of
//   any variable that keeps track of how many items are in a stack.
//
// CONSTRUCTOR for the stack class:
//   stack( )
//     Postcondition: The stack has been initialized as an empty stack.
//
// MODIFICATION MEMBER FUNCTIONS for the stack class:
//   void push(const value_type& entry)
//     Precondition: size( ) < CAPACITY.
//     Postcondition: A new copy of entry has been pushed onto the stack.
//
//   void pop( )
//     Precondition: size( ) > 0.
//     Postcondition: The top item of the stack has been removed.
//
// CONSTANT MEMBER FUNCTIONS for the stack class:
//   bool empty( ) const
//     Postcondition: Return value is true if the stack is empty.
//
//   size_type size( ) const
//     Postcondition: Return value is the total number of items in the stack.
//
//   value_type top( ) const
//     Precondition: size( ) > 0.
//     Postcondition: The return value is the top item of the stack (but the
//     stack is unchanged. This differs slightly from the STL stack (where
//     the top function returns a reference to the item on top of the stack).
//
// VALUE SEMANTICS for the stack class:
//   Assignments and the copy constructor may be used with stack 
//   objects.
//
// DYNAMIC MEMORY USAGE by the stack template class:
//   If there is insufficient dynamic memory, then the following functions
//   throw bad_alloc:
//   the copy constructor, push, and the assignment operator.

#ifndef MAIN_SAVITCH_STACK2_H
#define MAIN_SAVITCH_STACK2_H
#include <cstdlib>   // Provides NULL and size_t
#include "node2.h"   // Node template class from Figure 5.4 on page 226

namespace ivc_cs41_pa2
{
    class stack
    {
    public:
        // TYPEDEFS 
        typedef std::size_t size_type;
        typedef node::value_type value_type;
        
	  // Complete the rest of this class definition with the 
	  // prototypes of member functions

	  // CONSTRUCTORS and DESTRUCTOR
        stack( ) �
        stack(const stack& source)� 
        ~stack( ) �
        // MODIFICATION MEMBER FUNCTIONS
        push() �
	  pop() �
	  operator= functions 
        // CONSTANT MEMBER FUNCTIONS
        top()�
	  size( ) �
        empty( ) �
        
    private:
        node *top_ptr;  // Points to top of stack
    };
}
#endif
