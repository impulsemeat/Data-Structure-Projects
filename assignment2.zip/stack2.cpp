// FILE: stack2.cpp
// CLASS IMPLEMENTED: stack (see stack2.h for documentation)
// INVARIANT for the stack class:
//   1. The items in the stack are stored in a linked list, with the top of the
//      stack stored at the head node, down to the bottom of the stack at the
//      final node.
//   2. The member variable top_ptr is the head pointer of the linked list.

#include <cassert>  // Provides assert
#include "node1.h"  // Node class and Linked_list Toolkit

namespace ivc_cs41_pa2
{
//Codes that implement the functions specified in stack class definition

//This part is to be completed by stidents
    . . .
}
