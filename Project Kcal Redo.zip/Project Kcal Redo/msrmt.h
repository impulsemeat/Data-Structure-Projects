#ifndef MSRMT_H_INCLUDED
#define MSRMT_H_INCLUDED

class Msrmt//This class represent a Person with his/her body data, including bodyweight and body fat.
{
    public:
        Msrmt(){ BW = 50, BF = 20; }
        Msrmt(const Msrmt& source){ BW = source.BW, BF = source.BF; }
        Msrmt(float newBW, float newBF){ BW = newBW, BF = newBF; }
        void reset(float newBW, float newBF);
        void setBW(float newBW);
        void setBF(float newBF);
        float getNW();//get body net weight
        float getBMR();//get Base Metabolism Rate
        float getTrBn(float TrTm);// get the calorie burned by training, training time needed
    private:
        float BW, BF;
};


#endif // MSRMT_H_INCLUDED
