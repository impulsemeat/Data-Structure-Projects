#include<iostream>
#include "msrmt.h"

using namespace std;

float totalBurn(Msrmt&, const float&);
void displayAll(Msrmt&, const float&);

int main()
{
    float newBW, newBF;
    int TrTm;
    cout << "Enter your bodyweight in kg: ";
    cin >> newBW;
    cout << "Enter your body fat in (%): ";
    cin >> newBF;
    cout << "Enter your training time in minutes: ";
    cin >> TrTm;
    //to initialize bodyWeight and bodyFat;
    Msrmt P1(newBW, newBF);
    displayAll(P1, (float)TrTm);

   /* float netWeight;
    netWeight = BW*(100 - BF)/100.000;
    float& NW = netWeight;
    cout << "\nYour net weight {without fat} is " << NW << " kg\n";
    float BMR = NW * 12.5 / 0.454;//BMR = Base Metabolism Rate
    cout << "Your base metabolism rate is " << BMR << " kcal\n";
    float trainingBurn = 0.086 * BW * TrTm;
    float& TrBn = trainingBurn;
    cout << "The additional calories burned by your training is " << TrBn << " kcal\n";
    float totalBurn = BMR + trainingBurn;
    float& ttlBn = totalBurn;
    cout << "The total calories burned today is " << ttlBn << " kcal\n";*/
    // Carbs & Protein: 1g = 4kcal;
    // Fat: 1g = 9kcal;


    return 0;
}

float totalBurn(Msrmt& p, const float& tm)
{
    return p.getBMR() + p.getTrBn(tm);
}
void displayAll(Msrmt& p, const float& tm)
{
    cout << "\nYour net weight {without fat} is " << p.getNW() << " kg;\n";
    cout << "Your base metabolism rate is " << p.getBMR() << " kcal;\n";
    cout << "The additional calories burned by your training is " << p.getTrBn(tm) << " kcal;\n";
    cout << "The total calories burned today is " << totalBurn(p, tm) << " kcal.\n";
}
