#include "msrmt.h"

void Msrmt::setBW(float newBW){ BW = newBW; }
void Msrmt::setBF(float newBF){ BF = newBF; }
void Msrmt::reset(float newBW, float newBF)
{
    setBW(newBW);
    setBF(newBF);
}
float Msrmt::getNW()
{
    return BW*(100 - BF)/100.000;
}
float Msrmt::getBMR()
{
    return this->getNW() * 12.5 / 0.454;//BMR = Base Metabolism Rate
}
float Msrmt::getTrBn(float TrTm)
{
    return 0.086 * BW * TrTm;
}

